from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from apps.api.app.db.session import get_db
from apps.api.app.repositories.producer import ProducerRepository
from apps.api.app.schemas.orders import OrderRead
from apps.api.app.schemas.products import ProductRead

router = APIRouter()


@router.get("/products", response_model=list[ProductRead])
def list_producer_products(db: Session = Depends(get_db)) -> list[ProductRead]:
    """List products visible to the producer portal.

    MVP note: authentication/RBAC is deferred. The first producer is used as
    the demo producer until JWT permissions are implemented.
    """

    return ProducerRepository(db).list_demo_producer_products()


@router.get("/orders", response_model=list[OrderRead])
def list_producer_orders(db: Session = Depends(get_db)) -> list[OrderRead]:
    """List orders visible to the producer portal."""

    return ProducerRepository(db).list_demo_producer_orders()

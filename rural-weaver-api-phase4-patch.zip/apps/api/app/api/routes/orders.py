from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from apps.api.app.db.session import get_db
from apps.api.app.repositories.admin import AdminRepository
from apps.api.app.schemas.orders import OrderRead

router = APIRouter()


@router.get("", response_model=list[OrderRead])
def list_orders_for_smoke_test(
    db: Session = Depends(get_db),
) -> list[OrderRead]:
    """Temporary read-only order list.

    Full public order creation will be implemented in the next phase.
    """

    return AdminRepository(db).list_orders()

from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class OrderRead(BaseModel):
    """Order representation for admin and producer screens."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    customer_name: str
    customer_phone: str
    customer_email: str | None
    delivery_type: str
    pickup_point: str | None
    address: str | None
    status: str
    payment_method: str
    payment_status: str
    subtotal: Decimal
    total: Decimal
    notes: str | None
